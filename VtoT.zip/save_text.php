<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "vtot";

try {
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        throw new Exception("فشل الاتصال: " . $conn->connect_error);
    }

    if (!isset($_POST["text"])) {
        throw new Exception("لم يتم استلام النص");
    }

    $text = $_POST["text"];

    $stmt = $conn->prepare("INSERT INTO text_table (text) VALUES (?)");
    if (!$stmt) {
        throw new Exception("خطأ في إعداد الاستعلام: " . $conn->error);
    }

    $stmt->bind_param("s", $text);

    if (!$stmt->execute()) {
        throw new Exception("خطأ عند تنفيذ الاستعلام: " . $stmt->error);
    }

    echo "تم حفظ النص بنجاح";

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    echo "خطأ: " . $e->getMessage();
}
?>